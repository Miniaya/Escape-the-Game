const riddles = [
  {
    "riddle": "I'm not a blanket, yet I cover the ground; a crystal from heaven that doesn't make a sound. What am I?",
    "answerOptions": [
      "Diamond",
      "Snowflake",
      "Glass"
    ],
    "correctAnswer": 1
  },
  {
    "riddle": "I have a neck, but no head. I have two arms, but no hands. What am I?",
    "answerOptions": [
      "A shirt",
      "A bottle",
      "A giraffe"
    ],
    "correctAnswer": 0
  },
  {
    "riddle": "The more you take, the more you leave behind. What am I?",
    "answerOptions": [
      "Food",
      "Books",
      "Footsteps"
    ],
    "correctAnswer": 2
  },
];