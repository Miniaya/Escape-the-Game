class Breakpoints {
  static const sm = 640;
}